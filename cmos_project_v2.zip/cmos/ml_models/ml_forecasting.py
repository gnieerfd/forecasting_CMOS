"""
ml_models/ml_forecasting.py
Energy Demand Forecasting pipeline using XGBoost + Scikit-learn.
Supports CSV / XLSX upload with automatic feature engineering.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import streamlit as st
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from xgboost import XGBRegressor

# ── Target column candidates (checked in order) ───────────────────────────
_TARGET_CANDIDATES = [
    "Energy Demand EV (kWh)",
    "energy_demand_ev",
    "Energy_Demand",
    "demand_kwh",
    "kWh",
    "energy",
]

# ── Timestamp column candidates ───────────────────────────────────────────
_TIME_CANDIDATES = [
    "Tanggal",
    "Date",
    "date",
    "timestamp",
    "Time_Stamp",
    "datetime",
    "waktu",
]


# ── Helpers ───────────────────────────────────────────────────────────────

def _find_column(df: pd.DataFrame, candidates: list[str]) -> str | None:
    """Return the first candidate column name that exists in df (case-insensitive)."""
    lower_cols = {c.lower(): c for c in df.columns}
    for cand in candidates:
        if cand in df.columns:
            return cand
        if cand.lower() in lower_cols:
            return lower_cols[cand.lower()]
    return None


def _engineer_features(df: pd.DataFrame, time_col: str) -> pd.DataFrame:
    """Add time-based features from a datetime column."""
    df = df.copy()
    df[time_col] = pd.to_datetime(df[time_col], errors="coerce")
    df = df.dropna(subset=[time_col]).sort_values(time_col).reset_index(drop=True)

    df["year"]        = df[time_col].dt.year
    df["month"]       = df[time_col].dt.month
    df["day"]         = df[time_col].dt.day
    df["dayofweek"]   = df[time_col].dt.dayofweek
    df["dayofyear"]   = df[time_col].dt.dayofyear
    df["weekofyear"]  = df[time_col].dt.isocalendar().week.astype(int)
    df["quarter"]     = df[time_col].dt.quarter
    df["hour"]        = df[time_col].dt.hour
    df["is_weekend"]  = (df["dayofweek"] >= 5).astype(int)

    # Lag features
    df["lag_1"]  = df["__target__"].shift(1)
    df["lag_7"]  = df["__target__"].shift(7)
    df["lag_30"] = df["__target__"].shift(30)

    # Rolling stats
    df["roll_mean_7"]  = df["__target__"].shift(1).rolling(7,  min_periods=1).mean()
    df["roll_std_7"]   = df["__target__"].shift(1).rolling(7,  min_periods=1).std().fillna(0)
    df["roll_mean_30"] = df["__target__"].shift(1).rolling(30, min_periods=1).mean()

    return df


def _mock_dataframe(n: int = 365) -> pd.DataFrame:
    """Generate a synthetic dataset when no real data is supplied."""
    rng = np.random.default_rng(42)
    dates = pd.date_range("2024-01-01", periods=n, freq="D")
    base  = 50 + 20 * np.sin(np.linspace(0, 4 * np.pi, n))
    noise = rng.normal(0, 5, n)
    return pd.DataFrame(
        {
            "Tanggal": dates,
            "Energy Demand EV (kWh)": np.clip(base + noise, 10, None),
        }
    )


# ── Public API ────────────────────────────────────────────────────────────

@st.cache_data(show_spinner=False)
def run_forecast(
    file_bytes: bytes,
    file_name: str,
    test_size: float = 0.2,
    n_estimators: int = 300,
    max_depth: int = 6,
    learning_rate: float = 0.05,
) -> dict:
    """
    Full forecasting pipeline.

    Returns
    -------
    dict with keys:
        df_hist    – historical DataFrame (date + actual)
        df_pred    – predictions DataFrame (date + actual + predicted)
        metrics    – dict of MAPE, MAE, MSE, RMSE, R²
        model_name – str
        feature_importance – pd.Series
    """
    # 1. Load ──────────────────────────────────────────────────────────────
    try:
        import io
        buf = io.BytesIO(file_bytes)
        if file_name.endswith(".xlsx"):
            df = pd.read_excel(buf)
        else:
            # Try common separators
            for sep in [",", ";", "\t"]:
                buf.seek(0)
                try:
                    df = pd.read_csv(buf, sep=sep)
                    if df.shape[1] > 1:
                        break
                except Exception:
                    continue
    except Exception as exc:
        raise ValueError(f"Gagal membaca file: {exc}") from exc

    # 2. Identify columns ──────────────────────────────────────────────────
    time_col   = _find_column(df, _TIME_CANDIDATES)
    target_col = _find_column(df, _TARGET_CANDIDATES)

    if time_col is None:
        # fallback: use row index as date
        df["__date__"] = pd.date_range("2024-01-01", periods=len(df), freq="D")
        time_col = "__date__"

    if target_col is None:
        # pick first numeric column
        numeric_cols = df.select_dtypes(include=np.number).columns.tolist()
        if not numeric_cols:
            raise ValueError(
                "Tidak ditemukan kolom numerik dalam dataset. "
                "Pastikan file memiliki kolom angka (energi/demand)."
            )
        target_col = numeric_cols[0]

    df = df[[time_col, target_col]].rename(columns={target_col: "__target__"})
    df = _engineer_features(df, time_col)
    df = df.dropna().reset_index(drop=True)

    if len(df) < 20:
        raise ValueError(
            f"Data terlalu sedikit setelah preprocessing ({len(df)} baris). "
            "Minimal diperlukan 20 baris data."
        )

    # 3. Train / test split ────────────────────────────────────────────────
    FEATURE_COLS = [
        "year","month","day","dayofweek","dayofyear","weekofyear","quarter",
        "hour","is_weekend","lag_1","lag_7","lag_30",
        "roll_mean_7","roll_std_7","roll_mean_30",
    ]
    X = df[FEATURE_COLS]
    y = df["__target__"]

    split_idx = int(len(df) * (1 - test_size))
    X_train, X_test = X.iloc[:split_idx], X.iloc[split_idx:]
    y_train, y_test = y.iloc[:split_idx], y.iloc[split_idx:]

    # 4. Scale ─────────────────────────────────────────────────────────────
    scaler  = StandardScaler()
    X_train_s = scaler.fit_transform(X_train)
    X_test_s  = scaler.transform(X_test)

    # 5. Fit XGBoost ───────────────────────────────────────────────────────
    model = XGBRegressor(
        n_estimators=n_estimators,
        max_depth=max_depth,
        learning_rate=learning_rate,
        subsample=0.8,
        colsample_bytree=0.8,
        random_state=42,
        verbosity=0,
        tree_method="hist",
    )
    model.fit(X_train_s, y_train, eval_set=[(X_test_s, y_test)], verbose=False)

    # 6. Predict ───────────────────────────────────────────────────────────
    y_pred = model.predict(X_test_s)
    y_pred = np.clip(y_pred, 0, None)   # energy can't be negative

    # 7. Metrics ───────────────────────────────────────────────────────────
    eps = 1e-9
    mape = float(np.mean(np.abs((y_test.values - y_pred) / (np.abs(y_test.values) + eps))) * 100)
    mae  = float(mean_absolute_error(y_test, y_pred))
    mse  = float(mean_squared_error(y_test, y_pred))
    rmse = float(np.sqrt(mse))
    r2   = float(r2_score(y_test, y_pred))

    # 8. Build output DataFrames ───────────────────────────────────────────
    df_hist = df[[time_col, "__target__"]].copy()
    df_hist.columns = ["Tanggal", "Aktual"]

    df_pred = df.iloc[split_idx:].copy()
    df_pred = df_pred[[time_col, "__target__"]].copy()
    df_pred.columns = ["Tanggal", "Aktual"]
    df_pred["Prediksi"] = y_pred

    feat_imp = pd.Series(model.feature_importances_, index=FEATURE_COLS).sort_values(ascending=False)

    return {
        "df_hist":            df_hist,
        "df_pred":            df_pred,
        "metrics":            {"MAPE": mape, "MAE": mae, "MSE": mse, "RMSE": rmse, "R²": r2},
        "model_name":         "XGBoost Regressor",
        "feature_importance": feat_imp,
    }
