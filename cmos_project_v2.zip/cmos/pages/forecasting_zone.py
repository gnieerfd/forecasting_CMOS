"""
pages/forecasting_zone.py
Energy Demand Forecasting page – CMOS
"""
from __future__ import annotations

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import pandas as pd
import streamlit as st

from components.charts import feature_importance_bar, forecast_line_chart
from ml_models.ml_forecasting import run_forecast


def render_forecasting_zone() -> None:
    # ── Header ────────────────────────────────────────────────────────────
    st.markdown(
        "<h1 style='font-size:2rem;font-weight:800;margin-bottom:0.2rem;'>"
        "📈 Energy Demand Forecasting</h1>",
        unsafe_allow_html=True,
    )
    st.markdown(
        "<p style='color:#8892a4;margin-top:0;margin-bottom:1.5rem;'>"
        "Upload dataset historis untuk memulai prediksi menggunakan XGBoost ML Pipeline."
        "</p>",
        unsafe_allow_html=True,
    )
    st.divider()

    # ── Two-column layout ─────────────────────────────────────────────────
    col_upload, col_viz = st.columns([1, 1.8], gap="large")

    # ── Left: Upload + warning ────────────────────────────────────────────
    with col_upload:
        st.markdown(
            "<h3 style='font-size:1.2rem;margin-bottom:0.6rem;'>📁 Upload Dataset</h3>",
            unsafe_allow_html=True,
        )
        uploaded = st.file_uploader(
            "Unggah dataset (CSV/XLSX)",
            type=["csv", "xlsx"],
            accept_multiple_files=False,
            help="Limit 200 MB. File harus memiliki kolom tanggal dan energi (kWh).",
        )

        if uploaded is None:
            st.warning("⚠️ Silakan unggah file CSV/XLSX untuk memulai forecasting.")
        else:
            # Config expander
            with st.expander("⚙️ Parameter Model", expanded=False):
                test_pct   = st.slider("Persentase data uji (%)", 10, 40, 20) / 100
                n_est      = st.slider("n_estimators (pohon)", 100, 600, 300, step=50)
                depth      = st.slider("max_depth", 3, 10, 6)
                lr         = st.slider("learning_rate", 0.01, 0.30, 0.05, step=0.01)

            run_btn = st.button("🚀 Jalankan Forecasting", use_container_width=True, type="primary")

            if run_btn or "forecast_result" in st.session_state:
                if run_btn:
                    # Cache-key includes file name + size so re-upload invalidates cache
                    file_bytes = uploaded.read()
                    with st.spinner("Melatih model XGBoost … mohon tunggu …"):
                        try:
                            result = run_forecast(
                                file_bytes=file_bytes,
                                file_name=uploaded.name,
                                test_size=test_pct,
                                n_estimators=n_est,
                                max_depth=depth,
                                learning_rate=lr,
                            )
                            st.session_state["forecast_result"] = result
                        except ValueError as e:
                            st.error(f"❌ {e}")
                            st.session_state.pop("forecast_result", None)
                            return
                        except Exception as e:
                            st.error(f"❌ Error tidak terduga: {e}")
                            st.session_state.pop("forecast_result", None)
                            return

                result = st.session_state.get("forecast_result")
                if result is None:
                    return

                # Preview data
                st.markdown("**Preview Dataset (5 baris pertama):**")
                preview = pd.concat(
                    [result["df_hist"], result["df_pred"].drop(columns=["Prediksi"], errors="ignore")]
                ).head(5)
                st.dataframe(preview, use_container_width=True, hide_index=True)

    # ── Right: Visualization + metrics ───────────────────────────────────
    with col_viz:
        st.markdown(
            "<h3 style='font-size:1.2rem;margin-bottom:0.6rem;'>📊 Visualisasi Forecasting</h3>",
            unsafe_allow_html=True,
        )

        result = st.session_state.get("forecast_result")

        if result is None:
            # Empty placeholder chart
            import plotly.graph_objects as go
            placeholder = go.Figure()
            placeholder.update_layout(
                paper_bgcolor="#0e1117",
                plot_bgcolor="#1c2333",
                xaxis=dict(title="Tanggal", gridcolor="#1e2a3a", color="#8892a4"),
                yaxis=dict(title="Energy Demand EV (kWh)", gridcolor="#1e2a3a", color="#8892a4"),
                font=dict(color="#8892a4"),
                margin=dict(l=50, r=20, t=30, b=50),
                annotations=[
                    dict(
                        text="Upload file untuk melihat grafik forecasting",
                        x=0.5, y=0.5,
                        xref="paper", yref="paper",
                        showarrow=False,
                        font=dict(size=14, color="#556"),
                    )
                ],
            )
            st.plotly_chart(placeholder, use_container_width=True)
        else:
            # Forecast line chart
            fig = forecast_line_chart(result["df_hist"], result["df_pred"])
            st.plotly_chart(fig, use_container_width=True)

        # ── Evaluation Metrics ─────────────────────────────────────────
        st.markdown(
            "<h3 style='font-size:1.2rem;margin-top:0.5rem;margin-bottom:0.4rem;'>"
            "📐 Evaluation Metrics</h3>",
            unsafe_allow_html=True,
        )

        if result:
            m = result["metrics"]
            mc1, mc2, mc3, mc4, mc5 = st.columns(5)
            mc1.metric("MAPE", f"{m['MAPE']:.2f}%")
            mc2.metric("MAE",  f"{m['MAE']:.4f}")
            mc3.metric("MSE",  f"{m['MSE']:.4f}")
            mc4.metric("RMSE", f"{m['RMSE']:.4f}")
            mc5.metric("R²",   f"{m['R²']:.4f}")

            # Metrics comparison table
            metrics_df = pd.DataFrame(
                [
                    {
                        "Model": result["model_name"],
                        "MAPE":  f"{m['MAPE']:.2f}%",
                        "MAE":   f"{m['MAE']:.4f}",
                        "MSE":   f"{m['MSE']:.4f}",
                        "RMSE":  f"{m['RMSE']:.4f}",
                        "R²":    f"{m['R²']:.4f}",
                    }
                ]
            )
            st.dataframe(metrics_df, use_container_width=True, hide_index=True)

            # Feature importance
            with st.expander("🔍 Feature Importance", expanded=False):
                fig_fi = feature_importance_bar(result["feature_importance"])
                st.plotly_chart(fig_fi, use_container_width=True)
        else:
            # Placeholder metrics table
            placeholder_df = pd.DataFrame(
                [{"Model": "–", "MAPE": "–", "MAE": "–", "MSE": "–", "RMSE": "–", "R²": "–"}]
            )
            mc1, mc2, mc3, mc4, mc5 = st.columns(5)
            mc1.metric("MAPE", "–")
            mc2.metric("MAE",  "–")
            mc3.metric("MSE",  "–")
            mc4.metric("RMSE", "–")
            mc5.metric("R²",   "–")
            st.dataframe(placeholder_df, use_container_width=True, hide_index=True)
