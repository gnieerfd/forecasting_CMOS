"""
CMOS - Charging Station Management System
Main application entry point
"""
import streamlit as st

# ── Page config (MUST be first Streamlit call) ──────────────────────────────
st.set_page_config(
    page_title="CMOS – Charging Station Management System",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Import pages ─────────────────────────────────────────────────────────────
from pages.forecasting_zone        import render_forecasting_zone
from pages.energy_monitoring       import render_energy_monitoring
from pages.dashboard_lokasi        import render_dashboard_lokasi
from pages.data_rinci_charger      import render_data_rinci_charger
from pages.kelola_pengguna         import render_kelola_pengguna
from pages.kelola_send_data        import render_kelola_send_data
from pages.laporan_transaksi       import render_laporan_transaksi
from pages.monitoring_transaction  import render_monitoring_transaction
from pages.rincian_charger_aktif   import render_rincian_charger_aktif

# ── Global dark-theme CSS injection ──────────────────────────────────────────
st.markdown(
    """
    <style>
    /* ---- Root palette ---- */
    :root {
        --bg-main:    #0e1117;
        --bg-sidebar: #161b25;
        --bg-card:    #1c2333;
        --accent:     #00d4aa;
        --accent2:    #ff4b6e;
        --green-box:  #1e4030;
        --green-txt:  #7fe0b0;
        --border:     #2a3348;
        --text-main:  #e8eaf6;
        --text-muted: #8892a4;
    }

    /* ---- Hide default Streamlit chrome ---- */
    #MainMenu, footer, header { visibility: hidden; }

    /* ---- Global body ---- */
    html, body, [class*="css"] {
        background-color: var(--bg-main);
        color: var(--text-main);
        font-family: 'Segoe UI', 'Noto Sans', sans-serif;
    }

    /* ---- Sidebar ---- */
    [data-testid="stSidebar"] {
        background-color: var(--bg-sidebar) !important;
        border-right: 1px solid var(--border);
    }
    [data-testid="stSidebar"] .stSelectbox label,
    [data-testid="stSidebar"] h1,
    [data-testid="stSidebar"] h2,
    [data-testid="stSidebar"] h3,
    [data-testid="stSidebar"] p,
    [data-testid="stSidebar"] span { color: var(--text-main) !important; }

    /* ---- Green welcome box ---- */
    .welcome-box {
        background-color: var(--green-box);
        border: 1px solid #2e6b4f;
        border-radius: 8px;
        padding: 10px 14px;
        margin-bottom: 18px;
        color: var(--green-txt) !important;
        font-size: 0.9rem;
        font-weight: 600;
    }

    /* ---- Section headers ---- */
    .section-title {
        font-size: 2rem;
        font-weight: 800;
        color: var(--text-main);
        margin-bottom: 0.3rem;
    }

    /* ---- Metric cards ---- */
    [data-testid="metric-container"] {
        background: var(--bg-card);
        border: 1px solid var(--border);
        border-radius: 10px;
        padding: 12px 18px !important;
    }
    [data-testid="metric-container"] label { color: var(--text-muted) !important; }
    [data-testid="metric-container"] [data-testid="stMetricValue"] {
        color: var(--accent) !important;
        font-size: 1.6rem !important;
        font-weight: 700 !important;
    }

    /* ---- Buttons ---- */
    .stButton > button {
        background: transparent;
        border: 1px solid var(--border);
        color: var(--text-main);
        border-radius: 6px;
        font-size: 0.88rem;
        padding: 6px 18px;
        transition: all 0.2s;
    }
    .stButton > button:hover {
        border-color: var(--accent2);
        color: var(--accent2);
        background: rgba(255,75,110,0.07);
    }

    /* ---- Select box ---- */
    .stSelectbox > div > div {
        background: var(--bg-card) !important;
        border: 1px solid var(--border) !important;
        color: var(--text-main) !important;
        border-radius: 6px;
    }

    /* ---- File uploader ---- */
    [data-testid="stFileUploader"] {
        background: var(--bg-card);
        border: 1.5px dashed var(--border);
        border-radius: 10px;
        padding: 16px;
    }

    /* ---- Warning / info boxes ---- */
    .stAlert { border-radius: 8px; }

    /* ---- Dataframe ---- */
    [data-testid="stDataFrame"] { border-radius: 8px; overflow: hidden; }

    /* ---- Toggle ---- */
    [data-testid="stToggle"] label { color: var(--text-main) !important; }

    /* ---- Divider ---- */
    hr { border-color: var(--border); margin: 1.4rem 0; }

    /* ---- Logo container ---- */
    .logo-container {
        text-align: center;
        padding: 8px 0 14px 0;
    }
    .logo-text {
        font-size: 2.2rem;
        font-weight: 900;
        color: var(--accent);
        letter-spacing: 0.12em;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# ── Session state defaults ─────────────────────────────────────────────────
if "logged_in" not in st.session_state:
    st.session_state.logged_in = True          # mock: always logged in
if "username" not in st.session_state:
    st.session_state.username = "setyoajic"
if "role" not in st.session_state:
    st.session_state.role = "Superadmin"
if "page" not in st.session_state:
    st.session_state.page = "Dashboard Lokasi"

# ── Sidebar ────────────────────────────────────────────────────────────────
with st.sidebar:
    # Logo
    st.markdown(
        """
        <div class="logo-container">
            <span style="font-size:2.6rem;">⚡</span>
            <div class="logo-text">CMOS</div>
            <div style="font-size:0.7rem;color:#556;letter-spacing:0.18em;margin-top:-4px;">
                CHARGING STATION MGMT
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # Welcome box
    st.markdown(
        f"""
        <div class="welcome-box">
            Selamat datang, {st.session_state.username}<br>
            ({st.session_state.role})
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.markdown("### Navigasi")

    # Logout button
    if st.button("Logout", use_container_width=True):
        st.session_state.logged_in = False
        st.warning("Anda telah logout. Silakan refresh halaman.")
        st.stop()

    st.markdown("**Pilih Halaman**")
    page_options = [
        "Dashboard Lokasi",
        "Data Rinci Charger",
        "Kelola Pengguna dan Pelanggan",
        "Kelola Send Data CS",
        "Laporan Transaksi",
        "Monitoring Transaction",
        "Rincian Charger Aktif",
        "Forecasting Zone",
        "Energy Monitoring",
    ]

    # Clamp stored page to valid options
    if st.session_state.page not in page_options:
        st.session_state.page = page_options[0]

    selected_page = st.selectbox(
        "Pilih Halaman",
        page_options,
        index=page_options.index(st.session_state.page),
        label_visibility="collapsed",
    )
    st.session_state.page = selected_page

    # Extra sidebar settings for Energy Monitoring
    if selected_page == "Energy Monitoring":
        st.markdown("---")
        st.markdown("### ⚙️ Pengaturan")
        auto_refresh = st.toggle("Aktifkan Refresh Otomatis (10 detik)", value=False)
        if auto_refresh:
            from streamlit_autorefresh import st_autorefresh
            st_autorefresh(interval=10_000, key="energy_autorefresh")

# ── Route to page ─────────────────────────────────────────────────────────
_ROUTE_MAP = {
    "Dashboard Lokasi":              render_dashboard_lokasi,
    "Data Rinci Charger":            render_data_rinci_charger,
    "Kelola Pengguna dan Pelanggan": render_kelola_pengguna,
    "Kelola Send Data CS":           render_kelola_send_data,
    "Laporan Transaksi":             render_laporan_transaksi,
    "Monitoring Transaction":        render_monitoring_transaction,
    "Rincian Charger Aktif":         render_rincian_charger_aktif,
    "Forecasting Zone":              render_forecasting_zone,
    "Energy Monitoring":             render_energy_monitoring,
}

page_fn = _ROUTE_MAP.get(st.session_state.page)
if page_fn:
    page_fn()
else:
    st.error(f"Halaman '{st.session_state.page}' tidak ditemukan.")
