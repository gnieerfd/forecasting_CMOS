"""
services/db_service.py
SQLAlchemy ORM models + helper functions for CMOS MySQL database.
Requires: mysql-connector-python, SQLAlchemy==2.0.x
"""
from __future__ import annotations

import os
from datetime import datetime
from typing import Optional

import pandas as pd
import streamlit as st
from sqlalchemy import (
    Column,
    DateTime,
    Float,
    Integer,
    String,
    Text,
    create_engine,
    text,
)
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

# ── DB Config (override via env-vars or st.secrets) ──────────────────────
DB_USER     = os.getenv("DB_USER",     "root")
DB_PASSWORD = os.getenv("DB_PASSWORD", "")
DB_HOST     = os.getenv("DB_HOST",     "localhost")
DB_PORT     = os.getenv("DB_PORT",     "3306")
DB_NAME     = os.getenv("DB_NAME",     "cmos_db")

DATABASE_URL = (
    f"mysql+mysqlconnector://{DB_USER}:{DB_PASSWORD}"
    f"@{DB_HOST}:{DB_PORT}/{DB_NAME}"
)

# ── SQLAlchemy Base ───────────────────────────────────────────────────────
class Base(DeclarativeBase):
    pass


# ── ORM Models ───────────────────────────────────────────────────────────

class EnergyLog(Base):
    """Raw energy readings from transformer / meter."""
    __tablename__ = "energy_log"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    Time_Stamp      = Column(DateTime, nullable=False, index=True)
    Energy_Trafo_2  = Column(Float, nullable=True, comment="kWh reading")
    station_id      = Column(String(50), nullable=True, index=True)
    connector_id    = Column(Integer, nullable=True)
    created_at      = Column(DateTime, default=datetime.utcnow)

    def __repr__(self) -> str:
        return f"<EnergyLog id={self.id} ts={self.Time_Stamp} e={self.Energy_Trafo_2}>"


class Transaction(Base):
    """OCPP charging transactions."""
    __tablename__ = "transactions"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    transaction_id  = Column(Integer, nullable=False, unique=True, index=True)
    station_id      = Column(String(50), nullable=True)
    connector_id    = Column(Integer, nullable=True)
    id_tag          = Column(String(100), nullable=True)
    start_time      = Column(DateTime, nullable=True)
    stop_time       = Column(DateTime, nullable=True)
    meter_start     = Column(Float, nullable=True, comment="Wh")
    meter_stop      = Column(Float, nullable=True, comment="Wh")
    energy_kwh      = Column(Float, nullable=True, comment="kWh consumed")
    reason          = Column(String(50), nullable=True)
    created_at      = Column(DateTime, default=datetime.utcnow)


class MeterValue(Base):
    """Sampled measurand values per transaction."""
    __tablename__ = "meter_values"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    transaction_id  = Column(Integer, nullable=False, index=True)
    connector_id    = Column(Integer, nullable=True)
    timestamp       = Column(DateTime, nullable=False, index=True)
    measurand       = Column(String(100), nullable=True)
    value           = Column(Float, nullable=True)
    unit            = Column(String(20), nullable=True)
    context         = Column(String(50), nullable=True)
    created_at      = Column(DateTime, default=datetime.utcnow)


class EnergyForecast(Base):
    """Stored forecasting results."""
    __tablename__ = "energy_forecasts"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    run_date        = Column(DateTime, default=datetime.utcnow, index=True)
    model_name      = Column(String(100), nullable=True)
    mape            = Column(Float, nullable=True)
    mae             = Column(Float, nullable=True)
    mse             = Column(Float, nullable=True)
    rmse            = Column(Float, nullable=True)
    r2              = Column(Float, nullable=True)
    notes           = Column(Text, nullable=True)


# ── Engine & Session factory ──────────────────────────────────────────────

@st.cache_resource(show_spinner=False)
def get_engine():
    """Return a cached SQLAlchemy engine (connection pool)."""
    try:
        engine = create_engine(
            DATABASE_URL,
            pool_size=5,
            max_overflow=10,
            pool_pre_ping=True,
            echo=False,
        )
        # Quick ping to verify connectivity
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return engine
    except Exception as exc:
        st.warning(f"⚠️ Database tidak terhubung: {exc}. Menggunakan data mock.")
        return None


def get_session() -> Optional[Session]:
    engine = get_engine()
    if engine is None:
        return None
    SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    return SessionLocal()


def create_tables() -> None:
    engine = get_engine()
    if engine:
        Base.metadata.create_all(bind=engine)


# ── Query helpers ─────────────────────────────────────────────────────────

@st.cache_data(ttl=30, show_spinner=False)
def fetch_energy_log(station_id: str = "CS_Serpong", limit: int = 500) -> pd.DataFrame:
    """
    Fetch energy log rows for a given station.
    Falls back to synthetic mock data if DB is unavailable.
    """
    session = get_session()
    if session:
        try:
            rows = (
                session.query(EnergyLog)
                .filter(EnergyLog.station_id == station_id)
                .order_by(EnergyLog.Time_Stamp.desc())
                .limit(limit)
                .all()
            )
            session.close()
            if rows:
                return pd.DataFrame(
                    [
                        {
                            "Time_Stamp":     r.Time_Stamp,
                            "Energy_Trafo_2": r.Energy_Trafo_2,
                        }
                        for r in rows
                    ]
                )
        except Exception as exc:
            st.warning(f"DB query error: {exc}")
        finally:
            session.close()

    # ── Mock fallback ──────────────────────────────────────────────────
    return _mock_energy_log()


def _mock_energy_log() -> pd.DataFrame:
    """Generate realistic synthetic energy log data."""
    import numpy as np

    rng   = np.random.default_rng(7)
    dates = pd.date_range("2025-03-26 08:00", periods=28, freq="6h")
    base  = 188_000
    vals  = base + np.cumsum(rng.uniform(10, 200, len(dates)))

    return pd.DataFrame({"Time_Stamp": dates, "Energy_Trafo_2": vals.round(2)})


@st.cache_data(ttl=30, show_spinner=False)
def fetch_transactions(limit: int = 200) -> pd.DataFrame:
    """Fetch recent transactions. Falls back to mock."""
    session = get_session()
    if session:
        try:
            rows = (
                session.query(Transaction)
                .order_by(Transaction.transaction_id.desc())
                .limit(limit)
                .all()
            )
            session.close()
            if rows:
                return pd.DataFrame(
                    [
                        {
                            "transaction_id": r.transaction_id,
                            "connector_id":   r.connector_id,
                            "start_time":     r.start_time,
                            "energy_kwh":     r.energy_kwh,
                        }
                        for r in rows
                    ]
                )
        except Exception:
            pass
        finally:
            session.close()

    return _mock_transactions()


def _mock_transactions() -> pd.DataFrame:
    import numpy as np

    rng    = np.random.default_rng(11)
    n      = 10
    t_ids  = list(range(389, 389 + n))[::-1]
    dates  = pd.date_range("2026-04-08 08:00", periods=n, freq="3h")
    return pd.DataFrame(
        {
            "transaction_id": t_ids,
            "connector_id":   rng.integers(1, 3, n),
            "start_time":     dates,
            "energy_kwh":     rng.uniform(5, 50, n).round(2),
        }
    )
